<?php

  $conexion = mysqli_connect("localhost", "root", "root", "mydb");
  /*
  if($conexion){
    echo 'Conectado a la DB';
  } else {
    echo 'Error de conexion';
  }
  */
?>