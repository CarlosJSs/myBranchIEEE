<?php
  session_start();
  include 'conexion.php';

  $correo = $_POST['correo'];
  $contraseña = $_POST['contraseña'];

  $validar_login = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo='$correo'
  and contraseña='$contraseña'");

  //NOTA: NO SE PUEDE ACCEDER AL ARCHIVO bienvenida.php POR QUE FALTA COMPARAR LA CONTRASEÑA INGRESADA CONTRA LA CONTRASEÑA HASHEADA PARA ENTRAR

  if(mysqli_num_rows($validar_login) > 0 ){
    $_SESSION['usuario'] = $correo;
    header("location: ../bienvenida.php");
    exit;
  }else {
    echo '
      <script>
        alert("Usuario no existente, verifique sus datos!");
        window.location  = "../index.php";
      </script>
    ';
    exit();
  }

?>